
<footer class="main-footer" style="text-align:center">
        <strong>Design and Developed by Technical Department © <?php echo date("Y");?> ARS. </strong> All rights reserved.
</footer>
